public abstract class ExpenseBase {
    protected String category;
    protected double amount;
    protected String date;

    public abstract void display();
}
